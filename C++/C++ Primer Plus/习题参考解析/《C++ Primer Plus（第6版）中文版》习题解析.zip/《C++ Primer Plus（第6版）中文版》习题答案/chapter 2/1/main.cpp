#include <iostream>

int
main (void) 
{     

	using std::cout;
	using std::endl;

	cout << "我是yangyang.gnu, 定居成都。" << endl;
	
	cout << endl;
	return (0);
} 
