使用GCC 编译运行。

输入：
abc BCA 123 dge -XX
输出：
GaGBB1SdD-GbGCB2SgDXGcGAB3SeDX

与文档要求一致。