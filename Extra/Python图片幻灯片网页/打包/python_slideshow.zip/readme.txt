1.解压密码：timo1121

2.slideshow.py是代码，直接运行，输入keyword和确认是否排序后会生成slideshow.html网页文件，程序会自动打开。如果不能打开，就手动用浏览器打开即可。

3.empty_slideshow_files文件和文件夹，files.csv和images文件夹都不要删除。
