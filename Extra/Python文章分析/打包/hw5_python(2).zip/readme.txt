1.解压密码：timo1130

2.在上次的基础上，report里添加了两个文本对应的wordcloud，代码cloud.py修改过，直接运行就可以生成wordcloud，其他和上次一样